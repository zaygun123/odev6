let addtodobutton=document.getElementById('addtodo');
let todocontainer=document.getElementById('todocontainer');
let inputText=document.getElementById('inputText');
let cleartodo=document.getElementById('cleartodo');
addtodobutton.addEventListener('click',function(){
    let paragraph=document.createElement('p');
    paragraph.classList.add('paragraph-styling')
    todocontainer.appendChild(paragraph);
    paragraph.innerHTML=inputText.value;
    inputText.value="";

    paragraph.addEventListener('click',function(){
        paragraph.style.textDecoration='line-throught';
    })

    paragraph.addEventListener('dblclick',function(){
        todocontainer.removeChild(paragraph);
    });
    cleartodo.addEventListener('click',function(){
        paragraph.remove();
    })
})