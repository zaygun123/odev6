const userCards1 = document.querySelector('.card1')
const userCards2 = document.querySelector('.card2')
const userCards3 = document.querySelector('.card3')
const userCards4 = document.querySelector('.card4')
const userCards5 = document.querySelector('.card5')


async function getUsers1() {
   const response = await fetch('https://jsonplaceholder.typicode.com/users')
   const data = await response.json()

   let newData = data.slice(0,1)

   newData.forEach(user1 => {
         userCards1.innerHTML += `
         <div class="card" style="width: 18rem;">
           <div class="card-body">
            <h5 class="card-title">${user1.id}</h5>
            <p class="card-text ">${user1.name}</p>
            <p class="card-text">${user1.username}</p>
            <p class="card-text">${user1.email}</p>
            <p class="card-text">${user1.phone}</p>
           
          </div>
        </div>
         `   
   document.querySelector('.btn1').disabled = true
   });
}
async function getUsers2() {
    const response = await fetch('https://jsonplaceholder.typicode.com/users')
    const data = await response.json()
 
    let newData = data.slice(1,2)
 
    newData.forEach(user2 => {
          userCards2.innerHTML += `
          <div class="card" style="width: 18rem;">
            <div class="card-body">
             <h5 class="card-title">${user2.id}</h5>
             <p class="card-text ">${user2.name}</p>
             <p class="card-text">${user2.username}</p>
             <p class="card-text">${user2.email}</p>
             <p class="card-text">${user2.phone}</p>
            
           </div>
         </div>
          `   
    document.querySelector('.btn2').disabled = true
    });
 }
 async function getUsers3() {
    const response = await fetch('https://jsonplaceholder.typicode.com/users')
    const data = await response.json()
 
    let newData = data.slice(2,3)
 
    newData.forEach(user3 => {
          userCards3.innerHTML += `
          <div class="card" style="width: 18rem;">
            <div class="card-body">
             <h5 class="card-title">${user3.id}</h5>
             <p class="card-text ">${user3.name}</p>
             <p class="card-text">${user3.username}</p>
             <p class="card-text">${user3.email}</p>
             <p class="card-text">${user3.phone}</p>
            
           </div>
         </div>
          `   
    document.querySelector('.btn3').disabled = true
    });
 }
 async function getUsers4() {
    const response = await fetch('https://jsonplaceholder.typicode.com/users')
    const data = await response.json()
 
    let newData = data.slice(3,4)
 
    newData.forEach(user4 => {
          userCards4.innerHTML += `
          <div class="card" style="width: 18rem;">
            <div class="card-body">
             <h5 class="card-title">${user4.id}</h5>
             <p class="card-text ">${user4.name}</p>
             <p class="card-text">${user4.username}</p>
             <p class="card-text">${user4.email}</p>
             <p class="card-text">${user4.phone}</p>
            
           </div>
         </div>
          `   
    document.querySelector('.btn4').disabled = true
    });
 }
 async function getUsers5() {
    const response = await fetch('https://jsonplaceholder.typicode.com/users')
    const data = await response.json()
 
    let newData = data.slice(4,5)
 
    newData.forEach(user5 => {
          userCards5.innerHTML += `
          <div class="card" style="width: 18rem;">
            <div class="card-body">
             <h5 class="card-title">${user5.id}</h5>
             <p class="card-text ">${user5.name}</p>
             <p class="card-text">${user5.username}</p>
             <p class="card-text">${user5.email}</p>
             <p class="card-text">${user5.phone}</p>
            
           </div>
         </div>
          `   
    document.querySelector('.btn5').disabled = true
    });
 }
 const searchEl = document.getElementById('search')
const singleUserEl = document.querySelector('.single-user')

async function searchUser(searchInput) {
  const response = await fetch(`https://jsonplaceholder.typicode.com/users=${searchInput}`)
  const data = await response.json()

  singleUserEl.innerHTML += `
   <div class="card" style="width: 18rem;">
     <div class="card-body">
       <h5 class="card-title">${data[0].id}</h5>
       <p class="card-text ">${data[0].name}</p>
       <p class="card-text">${data[0].username}</p>
       <p class="card-text">${data[0].email}</p>
       <p class="card-text">${data[0].phone}</p>
      
     </div>
   </div>
  `
}

function getSingleUser() {
  let input = searchEl.value

  searchUser(input)
}