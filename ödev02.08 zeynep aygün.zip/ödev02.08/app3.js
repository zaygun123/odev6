const userCards1= document.querySelector('.cards')


async function getUsers() {
   const response = await fetch('https://jsonplaceholder.typicode.com/todos')
   const data = await response.json()

   let newData = data.slice(0,5)

   newData.forEach(user1 => {
         userCards1.innerHTML += `
         <div class="card" style="width: 18rem;">
           <div class="card-body">
            userID:<h5 class="card-title">${user1.userId}</h5>
            ID:<h5 class="card-title">${user1.id}</h5>

            title:<p class="card-text ">${user1.title}</p>
            completed:<p class="card-text">${user1.completed}</p>

           
          </div>
        </div>
         `   
   document.querySelector('.btn').disabled = true
   });
}